# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.1.2](https://github.com/Sewer56/CriFsV2Lib/compare/2.1.1...2.1.2) - 2023-11-24

### Merged

- Fix UTF8 encoding being used instead of Shift-JIS [`#6`](https://github.com/Sewer56/CriFsV2Lib/pull/6)

### Commits

- Bumped: Library Version [`9bf3b9c`](https://github.com/Sewer56/CriFsV2Lib/commit/9bf3b9c94015275db8d4f89be99454a4cd92d398)
