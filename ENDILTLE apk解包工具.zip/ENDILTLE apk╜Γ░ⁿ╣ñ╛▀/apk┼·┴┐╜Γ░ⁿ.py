import subprocess
import os

def decompress_apk(file_path):
    try:
        # 获取不带扩展名的文件名
        file_name_without_ext = os.path.splitext(os.path.basename(file_path))[0]

        # 创建与.apk文件同名的输出目录
        output_dir = os.path.join(os.path.dirname(file_path), file_name_without_ext)
        os.makedirs(output_dir, exist_ok=True)
        
        # 设置解包工具的路径
        apktool_path = "main.py"  # 假设解包工具的路径是当前文件夹中的main.py

        # 构建命令行参数
        command = [
            "python", apktool_path, "UNPACK_APK", "-i", file_path, "-o", output_dir
        ]

        # 执行解包命令
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)

        # 实时打印解压过程中的所有输出
        for line in process.stdout:
            print(line.strip())

        # 等待解包过程结束
        process.stdout.close()
        process.wait()

        # 检查解压是否成功
        if process.returncode == 0:
            print(f"Successfully decompressed {file_path} to {output_dir}")
        else:
            error_message = process.stderr.read().strip()
            print(f"Error decompressing {file_path}: {error_message}")

    except Exception as e:
        print(f"Error decompressing {file_path}: {str(e)}")

def find_apk_files(directory):
    apk_files = []
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.lower().endswith('.apk'):
                apk_files.append(os.path.join(root, file))
    return apk_files

def decompress_all_apks(directory):
    apk_files = find_apk_files(directory)
    if not apk_files:
        print("No APK files found in the specified directory.")
        return

    for apk_file in apk_files:
        print(f"Decompressing {apk_file}...")
        decompress_apk(apk_file)

if __name__ == "__main__":
    input_directory = input("请输入apk文件所在的路径(此apk非安卓的apk): ")
    decompress_all_apks(input_directory)