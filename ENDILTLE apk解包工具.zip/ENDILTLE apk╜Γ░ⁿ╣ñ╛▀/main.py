import argparse
import os
from scripts import help
from scripts.dump_apk import DumpApk
from scripts.dump_idx import DumpIdx
from scripts.pack_apk import PackApk
from scripts.unpack_apk import UnpackApk


class Main:
    def __init__(self):
        self.parser = None

    def main(self):
        self.init_argparse()
        args = self.parser.parse_args()

        if args.script is None:
            print(help.HELP_ALL)
            return

        # 权限检查
        if args.script == "UNPACK_APK":
            print(f"Input Path: {args.i}")
            print(f"Output Path: {args.o}")
            if not os.path.exists(args.i):
                print(f"输入路径不存在: {args.i}")
                return
            if not os.access(args.i, os.R_OK):
                print(f"没有读取权限: {args.i}")
                return
            if not os.access(args.o, os.W_OK):
                print(f"没有写入权限: {args.o}")
                return

        # 根据脚本类型调用相应的功能
        if args.script == "DUMP_APK":
            DumpApk(args.i, args.o, args.t, args.q).dump()
        elif args.script == "DUMP_IDX":
            DumpIdx(args.i, args.o, args.t, args.q).dump()
        elif args.script == "UNPACK_APK":
            UnpackApk(args.i, args.o, args.e, args.d).extract()
        elif args.script == "PACK_APK":
            PackApk(args.i, args.x, args.o, args.d).pack()

    def init_argparse(self):
        self.parser = argparse.ArgumentParser(description="The collection of tools for modding <Nisekoi Yomeiri!?>")
        subparser = self.parser.add_subparsers(dest="script")

        parser_dump_all_apk = subparser.add_parser("DUMP_APK", help="Dump APK files")
        parser_dump_all_apk.add_argument("-i", type=str, required=True)
        parser_dump_all_apk.add_argument("-o", type=str)
        parser_dump_all_apk.add_argument("-t", type=str, choices=["table", "json"], default="table")
        parser_dump_all_apk.add_argument("-q", action="store_true")

        parser_dump_idx = subparser.add_parser("DUMP_IDX", help="Dump IDX files")
        parser_dump_idx.add_argument("-i", type=str, required=True)
        parser_dump_idx.add_argument("-o", type=str)
        parser_dump_idx.add_argument("-t", type=str, choices=["table", "json"], default="table")
        parser_dump_idx.add_argument("-q", action="store_true")

        parser_unpack_apk = subparser.add_parser("UNPACK_APK", help="Unpack APK files")
        parser_unpack_apk.add_argument("-i", type=str, required=True)
        parser_unpack_apk.add_argument("-o", type=str, required=True)
        parser_unpack_apk.add_argument("-e", type=str, choices=["overwrite", "skip"], default="overwrite")
        parser_unpack_apk.add_argument("-d", action="store_true")

        parser_pack_apk = subparser.add_parser("PACK_APK", help="Pack APK files")
        parser_pack_apk.add_argument("-i", type=str, required=True, nargs=2)  # 确保提供两个路径
        parser_pack_apk.add_argument("-x", type=str)
        parser_pack_apk.add_argument("-o", type=str, required=True)
        parser_pack_apk.add_argument("-d", action="store_true")


if __name__ == "__main__":
    try:
        Main().main()
    except Exception as e:
        print(f"错误: {e}")
