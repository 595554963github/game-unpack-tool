import os
import zlib
from pathlib import Path
from typing import Literal

from scripts.BinaryManager import BinaryReader
from scripts.ByteSegment import ByteSegment

class UnpackApk:
    def __init__(self, i: str, o: str, e: Literal["overwrite", "skip"], d: bool):
        self.INPUT_APK_PATH = i
        self.OUTPUT_DIR_PATH = o
        self.FILE_EXISTS = e
        self.IS_DEBUG = d

    def print_d(self, s: str):
        if self.IS_DEBUG:
            print(s)

    def extract_file(self, out_path: str, file: bytearray, offset: int, is_same_name: bool, is_zip: bool):
        if is_zip:
            try:
                file = zlib.decompress(file)
            except zlib.error as e:
                print(f"解压缩文件时发生错误: {e}")
                return
        
        parent_dir = Path(out_path).parent
        parent_dir.mkdir(parents=True, exist_ok=True)

        if is_same_name:
            basename = Path(out_path).stem
            suffix = Path(out_path).suffix
            out_path = parent_dir / f"{basename}__OFS_{offset}{suffix}"

        if Path(out_path).exists():
            if self.FILE_EXISTS == "skip":
                return

        try:
            with open(out_path, "wb") as f:
                f.write(file)
            print(f"Extract File: {out_path}")
        except IOError as e:
            print(f"写入文件时发生错误: {e}")

    def extract(self):
        output_dir = Path(self.OUTPUT_DIR_PATH)
        output_dir.mkdir(parents=True, exist_ok=True)

        try:
            with open(self.INPUT_APK_PATH, "rb") as f:
                reader = BinaryReader(bytearray(f.read()))
                reader.seek(0)
                print(f"Read file from {self.INPUT_APK_PATH}")
                print(f"File Size: {reader.size()} bytes")
        except IOError as e:
            print(f"读取文件时发生错误: {e}")
            return

        DUMP = {
            "PACKTOC": {},
            "PACKFSLS": {},
            "GENESTRT": {},
            "FILE_AREA": {}
        }
        FILE_LIST = {}

        print("Parsing file header...")
        try:
            ENDIANESS = reader.read_string_bytes(8)
            ZERO = reader.get_buffer(8)

            print("Parsing PACKHEDR...")
            PACKHEDR = reader.read_string_bytes(8)
            HEADER_SIZE = reader.read_u64()
            _ = reader.get_buffer(8)  # Skipping unknown bytes
            FILE_LIST_OFFSET = reader.read_u32()
            _ = reader.get_buffer(4)  # Skipping unknown bytes
            _ = reader.get_buffer(16)  # Skipping unknown bytes

            print("Parsing PACKTOC...")
            PACKTOC = reader.read_string_bytes(8)
            HEADER_SIZE = reader.read_u64()
            packtoc_start_offset = reader.get_position()
            TOC_SEG_SIZE = reader.read_u32()
            TOC_SEG_COUNT = reader.read_u32()
            _ = reader.get_buffer(4)  # Skipping unknown bytes
            ZERO = reader.get_buffer(4)  # Skipping zero padding

            DUMP["PACKTOC"]["TOC_SEGMENT_LIST"] = []

            for _ in range(TOC_SEG_COUNT):
                IDENTIFIER = reader.read_u32()
                NAME_IDX = reader.read_u32()
                _ = reader.get_buffer(8)  # Skipping unknown bytes
                FILE_OFFSET = reader.read_u64()
                SIZE = reader.read_u64()
                ZSIZE = reader.read_u64()
                DUMP["PACKTOC"]["TOC_SEGMENT_LIST"].append({
                    "IDENTIFIER": ByteSegment("int", IDENTIFIER),
                    "NAME_IDX": ByteSegment("int", NAME_IDX),
                    "FILE_OFFSET": ByteSegment("offset", FILE_OFFSET),
                    "SIZE": ByteSegment("int", SIZE),
                    "ZSIZE": ByteSegment("int", ZSIZE)
                })

            pad_cnt = (packtoc_start_offset + HEADER_SIZE) - reader.get_position()
            _ = reader.get_buffer(pad_cnt)  # Skipping padding

            print("Parsing PACKFSLS...")
            PACKFSLS = reader.read_string_bytes(8)
            HEADER_SIZE = reader.read_u64()
            packfsls_start_offset = reader.get_position()
            ARCHIVE_COUNT = reader.read_u32()
            ARCHIVE_SEG_SIZE = reader.read_u32()
            _ = reader.get_buffer(4)  # Skipping unknown bytes
            _ = reader.get_buffer(4)  # Skipping unknown bytes

            DUMP["PACKFSLS"]["ARCHIVE_SEGMENT_LIST"] = []

            for _ in range(ARCHIVE_COUNT):
                NAME_IDX = reader.read_u32()
                _ = reader.get_buffer(4)  # Skipping unknown bytes
                ARCHIVE_OFFSET = reader.read_u64()
                SIZE = reader.read_u64()
                _ = reader.get_buffer(16)  # Skipping dummy bytes
                DUMP["PACKFSLS"]["ARCHIVE_SEGMENT_LIST"].append({
                    "NAME_IDX": ByteSegment("int", NAME_IDX),
                    "ARCHIVE_OFFSET": ByteSegment("offset", ARCHIVE_OFFSET),
                    "SIZE": ByteSegment("int", SIZE)
                })

            pad_cnt = (packfsls_start_offset + HEADER_SIZE) - reader.get_position()
            _ = reader.get_buffer(pad_cnt)  # Skipping padding

            print("Parsing GENESTRT...")
            GENESTRT = reader.read_string_bytes(8)
            GENESTRT_SIZE = reader.read_u64()
            genestrt_start_offset = reader.get_position()
            STR_OFFSET_COUNT = reader.read_u32()
            _ = reader.get_buffer(4)  # Skipping unknown bytes
            GENESTRT_SIZE = reader.read_u32()
            DUMP["GENESTRT"]["HEADER_SIZE+STR_OFFSET_LIST_SIZE"] = ByteSegment("int", GENESTRT_SIZE)
            GENESTRT_SIZE = reader.read_u32()

            DUMP["GENESTRT"]["STR_OFFSET_LIST"] = []

            for _ in range(STR_OFFSET_COUNT):
                DUMP["GENESTRT"]["STR_OFFSET_LIST"].append(ByteSegment("int", reader.read_u32()))
            pad_cnt = (genestrt_start_offset + DUMP["GENESTRT"]["HEADER_SIZE+STR_OFFSET_LIST_SIZE"].get_int()) - reader.get_position()
            DUMP["GENESTRT"]["PAD"] = ByteSegment("raw", reader.get_buffer(pad_cnt))

            DUMP["GENESTRT"]["STRING_LIST"] = []

            for _ in range(STR_OFFSET_COUNT):
                try:
                    DUMP["GENESTRT"]["STRING_LIST"].append(ByteSegment("str", reader.read_string_utf8()))
                except UnicodeDecodeError as e:
                    print(f"解码字符串时发生错误: {e}")
                    DUMP["GENESTRT"]["STRING_LIST"].append(ByteSegment("str", ""))  # 处理解码错误

            pad_cnt = (genestrt_start_offset + GENESTRT_SIZE) - reader.get_position()
            DUMP["GENESTRT"]["TABLE_PADDING"] = ByteSegment("raw", reader.get_buffer(pad_cnt))

            print("Parsing GENEEOF...")
            GENEEOF = reader.read_string_bytes(8)
            _ = reader.get_buffer(8)  # Skipping zero padding
            TABLE_PADDING = reader.get_buffer(FILE_LIST_OFFSET - reader.get_position())

            print("Parsing file area...")
            DUMP["FILE_AREA"]["ROOT_ARCHIVE"] = {}
            for toc_seg in DUMP["PACKTOC"]["TOC_SEGMENT_LIST"]:
                FNAME = str(DUMP["GENESTRT"]["STRING_LIST"][toc_seg["NAME_IDX"].get_int()])[:-1]
                IDENTIFIER = toc_seg["IDENTIFIER"].get_int()
                FILE_OFFSET = toc_seg["FILE_OFFSET"].get_int()
                SIZE = toc_seg["SIZE"].get_int()
                ZSIZE = toc_seg["ZSIZE"].get_int()

                reader.seek(FILE_OFFSET)
                real_size = SIZE if ZSIZE == 0 else ZSIZE
                if IDENTIFIER == 1 or real_size == 0:
                    print("File was skipped because IDENTIFIER 1 or size 0.")
                    self.print_d(f"    FNAME: {FNAME}    OFFSET: {FILE_OFFSET}")
                    continue

                FILE = reader.get_buffer(real_size)
                out_path = output_dir / FNAME
                FILE_LIST.setdefault(FNAME, [])
                FILE_LIST[FNAME].append({
                    "out_path": out_path,
                    "file": FILE,
                    "offset": FILE_OFFSET,
                    "zsize": ZSIZE,
                    "fname": FNAME
                })

            for i in range(ARCHIVE_COUNT):
                key = f"ARCHIVE #{i}"
                DUMP["FILE_AREA"][key] = {
                    "PACKFSHD": {},
                    "GENESTRT": {}
                }
                print(f"Parsing ARCHIVE #{i}")

                NAME_IDX = DUMP["PACKFSLS"]["ARCHIVE_SEGMENT_LIST"][i]["NAME_IDX"].get_int()
                ARCHIVE_OFFSET = DUMP["PACKFSLS"]["ARCHIVE_SEGMENT_LIST"][i]["ARCHIVE_OFFSET"].get_int()
                SIZE = DUMP["PACKFSLS"]["ARCHIVE_SEGMENT_LIST"][i]["SIZE"].get_int()
                ARCHIVE_NAME = str(DUMP["GENESTRT"]["STRING_LIST"][NAME_IDX])[:-1]

                reader.seek(ARCHIVE_OFFSET)
                ENDIANESS = reader.read_string_bytes(8)
                _ = reader.get_buffer(8)  # Skipping padding

                PACKFSHD = reader.read_string_bytes(8)
                HEADER_SIZE = reader.read_u64()
                _ = reader.get_buffer(4)  # Skipping dummy bytes
                FILE_SEG_SIZE = reader.read_u32()
                FILE_SEG_COUNT = reader.read_u32()
                SEG_COUNT = reader.read_u32()
                _ = reader.get_buffer(16)  # Skipping dummy bytes

                DUMP["FILE_AREA"][key]["PACKFSHD"]["FILE_SEG_LIST"] = []

                for _ in range(FILE_SEG_COUNT):
                    NAME_IDX = reader.read_u32()
                    ZIP = reader.read_u32()
                    OFFSET = reader.read_u64()
                    SIZE = reader.read_u64()
                    ZSIZE = reader.read_u64()
                    DUMP["FILE_AREA"][key]["PACKFSHD"]["FILE_SEG_LIST"].append({
                        "NAME_IDX": ByteSegment("int", NAME_IDX),
                        "ZIP": ByteSegment("int", ZIP),
                        "OFFSET": ByteSegment("offset", OFFSET),
                        "SIZE": ByteSegment("int", SIZE),
                        "ZSIZE": ByteSegment("int", ZSIZE)
                    })

                print("    Parsing GENESTRT...")
                GENESTRT = reader.read_string_bytes(8)
                GENESTRT_SIZE = reader.read_u64()
                genestrt_start_offset = reader.get_position()
                STR_OFFSET_COUNT = reader.read_u32()
                _ = reader.get_buffer(4)  # Skipping unknown bytes
                GENESTRT_SIZE = reader.read_u32()
                DUMP["FILE_AREA"][key]["GENESTRT"]["HEADER_SIZE+STR_OFFSET_LIST_SIZE"] = ByteSegment("int", GENESTRT_SIZE)
                GENESTRT_SIZE = reader.read_u32()
                DUMP["FILE_AREA"][key]["GENESTRT"]["GENESTRT_SIZE_2"] = ByteSegment("int", GENESTRT_SIZE)

                DUMP["FILE_AREA"][key]["GENESTRT"]["STR_OFFSET_LIST"] = []

                for _ in range(STR_OFFSET_COUNT):
                    DUMP["FILE_AREA"][key]["GENESTRT"]["STR_OFFSET_LIST"].append(ByteSegment("int", reader.read_u32()))
                pad_cnt = (genestrt_start_offset + DUMP["FILE_AREA"][key]["GENESTRT"]["HEADER_SIZE+STR_OFFSET_LIST_SIZE"].get_int()) - reader.get_position()
                _ = reader.get_buffer(pad_cnt)  # Skipping padding

                DUMP["FILE_AREA"][key]["GENESTRT"]["STRING_LIST"] = []

                for _ in range(STR_OFFSET_COUNT):
                    try:
                        DUMP["FILE_AREA"][key]["GENESTRT"]["STRING_LIST"].append(ByteSegment("str", reader.read_string_utf8()))
                    except UnicodeDecodeError as e:
                        print(f"解码字符串时发生错误: {e}")
                        DUMP["FILE_AREA"][key]["GENESTRT"]["STRING_LIST"].append(ByteSegment("str", ""))  # 处理解码错误

                pad_cnt = (genestrt_start_offset + GENESTRT_SIZE) - reader.get_position()
                DUMP["FILE_AREA"][key]["GENESTRT"]["TABLE_PADDING"] = ByteSegment("raw", reader.get_buffer(pad_cnt))

                DUMP["FILE_AREA"][key]["FILE_AREA"] = {}

                for file_seg in DUMP["FILE_AREA"][key]["PACKFSHD"]["FILE_SEG_LIST"]:
                    OFFSET = file_seg["OFFSET"].get_int()
                    ZSIZE = file_seg["ZSIZE"].get_int()
                    SIZE = file_seg["SIZE"].get_int()
                    NAME_IDX = file_seg["NAME_IDX"].get_int()
                    FNAME = str(DUMP["FILE_AREA"][key]["GENESTRT"]["STRING_LIST"][NAME_IDX])[:-1]

                    reader.seek(ARCHIVE_OFFSET + OFFSET)
                    real_size = SIZE if ZSIZE == 0 else ZSIZE
                    if real_size == 0:
                        print("FILE_SEGMENT was skipped because size 0.")
                        self.print_d(f"    FNAME: {FNAME}    OFFSET: {OFFSET}")
                        continue
                    FILE = reader.get_buffer(real_size)
                    out_path = output_dir / ARCHIVE_NAME / FNAME
                    FILE_LIST.setdefault(f"{ARCHIVE_NAME}/{FNAME}", [])
                    FILE_LIST[f"{ARCHIVE_NAME}/{FNAME}"].append({
                        "out_path": out_path,
                        "file": FILE,
                        "offset": ARCHIVE_OFFSET + OFFSET,
                        "zsize": ZSIZE,
                        "fname": f"{ARCHIVE_NAME}/{FNAME}"
                    })

        except Exception as e:
            print(f"解析文件时发生错误: {e}")
            return

        for fname, obj_list in FILE_LIST.items():
            is_same_name = len(obj_list) > 1
            for obj in obj_list:
                out_path = obj["out_path"]
                file = obj["file"]
                offset = obj["offset"]
                zsize = obj["zsize"]
                fname = obj["fname"]
                offset_hex = f"0x{offset:08X}"

                self.print_d(f"File info: FNAME: {fname}    OFFSET: {offset_hex}    ZSIZE: {zsize}    SIZE: {len(file)}")

                self.extract_file(out_path, file, offset, is_same_name, zsize != 0)

        print("Extraction complete")
