import subprocess
import os

def decompress_gpk(file_path, gpk_name):
    try:
        # 创建与.gpk文件同名的输出目录
        output_dir = os.path.join(os.path.dirname(file_path), gpk_name)
        os.makedirs(output_dir, exist_ok=True)

        # 构建命令行参数
        command = ["GPKTool.exe", file_path, output_dir]

        # 执行解包命令
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)

        # 读取输出并实时打印到命令行
        for output in iter(process.stdout.readline, ''):
            print(output.strip())

        # 等待解包过程结束
        process.wait()

        # 检查解压是否成功
        if process.returncode == 0:
            print(f"Successfully decompressed {gpk_name} to {output_dir}")
        else:
            # 如果解压失败，打印错误信息
            error_message = process.stderr.read().strip()
            print(f"Error decompressing {gpk_name}: {error_message}")

    except Exception as e:
        print(f"Error decompressing {gpk_name}: {str(e)}")

def decompress_all_gpk_files(directory_path):
    if not os.path.isdir(directory_path):
        print(f"The specified path '{directory_path}' is not a valid directory.")
        return

    for root, dirs, files in os.walk(directory_path):
        for file in files:
            if file.lower().endswith('.gpk'):
                file_path = os.path.join(root, file)
                gpk_name = os.path.splitext(os.path.basename(file_path))[0]
                decompress_gpk(file_path, gpk_name)

if __name__ == "__main__":
    directory_path = input("请输入一个有效的路径: ")
    decompress_all_gpk_files(directory_path)