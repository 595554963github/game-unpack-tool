import os
import subprocess

def is_valid_path(path):
    return os.path.isdir(path)

def find_tlg_files(directory):
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith('.tlg'):
                yield os.path.join(root, file)

def extract_tlg_files(executable_path, tlg_files):
    total_files = len(tlg_files)
    print(f"Total TLG files to extract: {total_files}")
    
    for index, tlg_file in enumerate(tlg_files):
        try:
            subprocess.run([executable_path, tlg_file], check=True)
            print(f"已解压 ({index+1}/{total_files}) {tlg_file}: {((index+1)/total_files)*100:.2f}%")
        except subprocess.CalledProcessError as e:
            print(f"解压失败 {tlg_file}: {e}")

def main():
    path = input("请输入目录的路径: ")
    if not is_valid_path(path):
        print("提供的路径不是一个有效的目录。")
        return
    
    # 获取当前脚本所在的目录
    script_dir = os.path.dirname(os.path.abspath(__file__))
    executable_path = os.path.join(script_dir, "TLGTest.exe")
    
    tlg_files = list(find_tlg_files(path))
    extract_tlg_files(executable_path, tlg_files)

if __name__ == "__main__":
    main()