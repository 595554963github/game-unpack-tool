import os
import subprocess

def is_extracted(pkg_file_path):
    # 假设解压后的文件/目录包含'_extracted'后缀
    extracted_dir = f"{pkg_file_path.rsplit('.', 1)[0]}_已解压"
    return os.path.exists(extracted_dir)

def extract_pkg(pkg_file_path, count, total):
    # 检查文件是否已经被解压
    if is_extracted(pkg_file_path):
        print(f"跳过已解压的文件: {pkg_file_path}")
        return

    # 构建命令行命令，假设pkgtoglb.py在当前目录下
    command = ['python', 'pkgtoglb.py', pkg_file_path]
    # 调用pkgtoglb.py解压文件
    try:
        subprocess.run(command, check=True)
        print(f"成功解压: {pkg_file_path}")
    except subprocess.CalledProcessError as e:
        print(f"解压失败: {pkg_file_path}")
        print(e)
    # 更新解压进度条
    progress = (count / total) * 100
    print(f"\r解压进度: {progress:.2f}%", end='')

def main():
    input_directory = input("请输入pkg文件的路径: ")
    if not os.path.isdir(input_directory):
        print(f"错误: {input_directory} 不是一个有效的目录。")
        return

    # 计算pkg文件的总数
    pkg_files = []
    for root, dirs, files in os.walk(input_directory):
        for file in files:
            if file.lower().endswith('.pkg'):
                pkg_files.append(os.path.join(root, file))

    total = len(pkg_files)
    if total == 0:
        print("没有找到任何.pkg文件")
        return

    print(f"总计 {total} 个pkg文件，开始解压...")
    # 遍历并解压所有pkg文件
    for count, pkg_file_path in enumerate(pkg_files, start=1):
        extract_pkg(pkg_file_path, count, total)
    print("\n解压完成。")

if __name__ == '__main__':
    main()
