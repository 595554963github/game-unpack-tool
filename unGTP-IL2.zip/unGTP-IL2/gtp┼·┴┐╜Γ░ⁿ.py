import subprocess
import os
import threading

def decompress_gtp_threaded(file_path):
    try:
        # 获取不带扩展名的文件名
        file_name_without_ext = os.path.splitext(os.path.basename(file_path))[0]

        # 获取当前脚本所在的目录
        script_dir = os.path.dirname(os.path.abspath(__file__))
        unGTP_path = os.path.join(script_dir, "unGTP-IL2.exe")
        output_path = os.path.join(os.path.dirname(file_path), file_name_without_ext)

        # 创建与.gtp文件同名的输出目录
        os.makedirs(output_path, exist_ok=True)

        # 构建命令行参数
        command = [unGTP_path, file_path, output_path]

        # 执行unGTP-IL2.exe
        subprocess.run(command, check=True)

        print(f"成功解压 {file_path} 到 {output_path}")
    except subprocess.CalledProcessError as e:
        print(f"解压失败 {file_path}: {e}")
    except Exception as e:
        print(f"错误: {e}")

def decompress_all_gtp_files(directory_path):
    if not os.path.isdir(directory_path):
        print(f"指定的路径 '{directory_path}' 不是一个有效的目录。")
        return

    # 找到所有.gtp文件
    gtp_files = [os.path.join(root, file) for root, dirs, files in os.walk(directory_path) for file in files if file.endswith('.gtp')]

    # 对每个.gtp文件，创建并启动一个新线程来执行解包操作
    for file_path in gtp_files:
        decompress_thread = threading.Thread(target=decompress_gtp_threaded, args=(file_path,))
        decompress_thread.start()

if __name__ == "__main__":
    directory_path = input("请输入包含 .gtp 文件的目录路径: ")
    decompress_all_gtp_files(directory_path)