import subprocess
import os

# 检查文件类型并获取文件列表
def get_files_by_type(directory_path, file_type):
    if file_type == 1:
        pac_files = []
        for root, dirs, files in os.walk(directory_path):
            for file in files:
                if file.endswith('.pac'):
                    file_path = os.path.join(root, file)
                    with open(file_path, "rb") as f:
                        header = f.read(5)
                        if header == b'\x46\x50\x41\x43\x80':
                            pac_files.append(file_path)
        return pac_files
    elif file_type == 2:
        pac_files = []
        for root, dirs, files in os.walk(directory_path):
            for file in files:
                if file.endswith('.pac'):
                    file_path = os.path.join(root, file)
                    with open(file_path, "rb") as f:
                        header = f.read(4)
                        if header == b'\x46\x50\x41\x43':
                            pac_files.append(file_path)
        return pac_files
    elif file_type == 3:
        hip_files = []
        for root, dirs, files in os.walk(directory_path):
            for file in files:
                if file.endswith('.hip'):
                    file_path = os.path.join(root, file)
                    with open(file_path, "rb") as f:
                        header = f.read(3)
                        if header == b'\x48\x49\x50':
                            hip_files.append(file_path)
        return hip_files
    return []

# 解压文件
def decompress_file(file_path, file_type):
    try:
        if file_type in (1, 2):
            # 解压 PAC 文件
            subprocess.run(["unpac", file_path], check=True)
            print(f"成功解压 PAC 文件 {file_path}")
        elif file_type == 3:
            # 解压 HIP 文件
            subprocess.run(["unpac", file_path], check=True)
            print(f"成功解压 HIP 文件 {file_path}")
    except subprocess.CalledProcessError as e:
        print(f"解压失败 {file_path}: {e}")

# 主函数
def main():
    print("选择文件类型进行解压：")
    print("1 - 字节序列为 46 50 41 43 80 的 PAC 文件")
    print("2 - 字节序列为 46 50 41 43 的 PAC 文件")
    print("3 - 字节序列为 48 49 50 的 HIP 文件")
    file_type = int(input("请输入文件类型（1/2/3）："))

    directory_path = input("请输入包含文件的目录路径: ")
    files_to_decompress = get_files_by_type(directory_path, file_type)

    if not files_to_decompress:
        print("没有找到任何符合条件的文件。")
        return

    for file_path in files_to_decompress:
        decompress_file(file_path, file_type)

if __name__ == "__main__":
    main()