import os
import sys
import subprocess

def count_files(directory):
    total_files = 0
    for root, dirs, files in os.walk(directory):
        for file in files:
            total_files += 1
    return total_files

def process_files(file_list, mode):
    for file in file_list:
        progress = (file_list.index(file) + 1) / len(file_list) * 100
        print(f"\r正在{'解压缩' if mode == 1 else '提取'}: {file} ({progress:.2f}%)", end="")
        try:
            if mode == 1:
                subprocess.run(["decompress.exe", file], check=True)
            elif mode == 2:
                subprocess.run(["extractor.exe", file], check=True)
        except subprocess.CalledProcessError as e:
            print(f"\n处理文件 {file} 时出错: {e}")
        except Exception as e:
            print(f"\n未知错误: {e}")
    print(f"\n{'解压缩' if mode == 1 else '提取'}完成。")

def list_files(directory, total_files):
    file_list = []
    for root, dirs, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)
            file_list.append(file_path)
            if len(file_list) % 100 == 0 or len(file_list) == total_files:
                progress = (len(file_list) / total_files) * 100
                print(f"\r正在统计文件数量: {len(file_list)}/{total_files} ({progress:.2f}%)", end="")
    print(f"\n文件夹中共有 {total_files} 个文件。")
    return file_list

def main():
    path = input("请输入一个有效的路径: ")
    if not os.path.isdir(path):
        print("输入的路径不是一个有效的目录。")
        sys.exit(1)

    total_files = count_files(path)
    file_list = list_files(path, total_files)

    print("\n选择操作模式:")
    print("1. 解压缩")
    print("2. 提取")
    mode = input("请输入模式编号: ")

    if mode not in ['1', '2']:
        print("无效的模式编号。")
        sys.exit(1)

    process_files(file_list, int(mode))

if __name__ == "__main__":
    main()
